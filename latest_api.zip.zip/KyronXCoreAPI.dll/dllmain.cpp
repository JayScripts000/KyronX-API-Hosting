#include "pch.h"
#include <windows.h>

extern "C" {
    
    __declspec(dllexport) void TransferScript(const char* luaScript) {
        if (luaScript == nullptr || strlen(luaScript) == 0) return;

        HANDLE hPipe = CreateFileA("\\\\.\\pipe\\KyronXPipe",
            GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);

        if (hPipe != INVALID_HANDLE_VALUE) {
            DWORD bytesWritten;
            WriteFile(hPipe, luaScript, strlen(luaScript), &bytesWritten, NULL);
            CloseHandle(hPipe);
        }
    }

    
    __declspec(dllexport) bool IsAttached() {
        HANDLE hPipe = CreateFileA("\\\\.\\pipe\\KyronXPipe",
            GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);

        if (hPipe != INVALID_HANDLE_VALUE) {
            CloseHandle(hPipe);
            return true;
        }
        return false;
    }
}

